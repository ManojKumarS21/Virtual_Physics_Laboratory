"use client";

import { LabScene } from "@/components/lab/LabScene";
import { LabHUD } from "@/components/lab/LabHUD";
import { LabProvider } from "@/lib/chemistry/LabContext";

export default function Home() {
  return (
    <LabProvider>
      <main className="relative w-full h-screen overflow-hidden bg-[#0b0f1a]">
        <LabHUD />
        <LabScene />
      </main>
    </LabProvider>
  );
}
