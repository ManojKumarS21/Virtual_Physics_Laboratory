import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: "ChemLab VR – Virtual Chemistry Laboratory",
  description:
    "An interactive 3D virtual chemistry laboratory for students to safely explore chemical experiments with realistic apparatus and reactions.",
  keywords: ["chemistry", "virtual lab", "science", "education", "3D"],
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} antialiased`}>{children}</body>
    </html>
  );
}
