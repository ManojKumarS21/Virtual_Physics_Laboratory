# Virtual Chemistry Lab – Complete Apparatus Logic Specification

This document defines the interaction rules, behaviors, and constraints for all apparatus in the virtual chemistry laboratory. These rules must remain consistent to maintain realistic laboratory simulation and prevent unintended behavior changes.

---

# 1. Global State Management (LabContext)

The virtual laboratory uses a centralized state system implemented with React `useReducer`.

The state tracks every apparatus and its properties including:

* Position in 3D space
* Rotation orientation
* Scale
* Holder relationship
* Chemical contents (if applicable)
* Interaction states such as dragging, heating, or holding chemicals

Each apparatus object contains structured properties that define its behavior in the laboratory.

The state also tracks:

* Currently dragged apparatus
* Salt currently held by the spatula
* Chemical contents inside test tubes
* Active chemical reactions
* Heating states

Whenever an apparatus moves, all objects attached to it update their position automatically.

For example:

If a test tube is inside a clamp, the tube follows the clamp.
If the retort stand moves, the clamp and tube move together.
If a test tube is inside a rack slot, it remains locked to that slot.

---

# 2. Dragging and Interaction System

All apparatus share a unified drag interaction system.

Dragging uses raycasting to detect the surface below the cursor. Apparatus can move only along valid surfaces such as:

* Workbench
* Shelf plates
* Rack plates
* Sink surface

When dragging begins, camera controls are temporarily disabled to avoid accidental camera movement.

When dragging ends, the apparatus checks for nearby snap positions.

If the object is close enough to a valid snap point, it automatically aligns to that location.

---

# 3. Magnetic Snapping Behavior

Certain apparatus use magnetic snapping to assist with precise positioning.

Test tubes snap into test tube rack holes.

Reagent bottles snap into shelf slots.

Droppers magnetically align with bottle mouths and test tube mouths.

Holders magnetically attach to test tubes when placed near the glass body.

Magnetic snapping activates only within a short distance threshold to avoid unintended snapping.

---

# 4. Chemistry Engine Logic

The chemistry engine controls chemical reactions inside test tubes.

The system tracks individual ions rather than complete compounds.

Examples include:

* Ag⁺
* Cl⁻
* SO₄²⁻
* NH₄⁺

Whenever new chemicals are added to a test tube, the engine checks if any reaction rule exists.

If a valid reaction occurs, the engine returns the resulting reaction state.

Reaction outputs include:

* Solution color
* Precipitate formation
* Gas evolution
* Dissolving reactions

Visual effects represent these reactions using animations such as bubbles, fumes, or solid particle formation.

Neutralization reactions automatically remove hydrogen ions and hydroxide ions when they meet.

---

# 5. Laboratory Spatula Logic

The spatula is used to transfer solid salts from salt dishes to test tubes.

When the spatula tip passes over a salt dish, the spatula scoops a small amount of salt.

The spatula can carry only one salt type at a time.

When salt is collected, a small powder pile appears on the spatula blade.

When the spatula carrying salt moves near a test tube, the following sequence occurs.

The spatula automatically lifts to the height of the test tube mouth.

The spatula tip aligns horizontally above the tube opening.

Once aligned, the spatula tilts slightly.

Salt particles spawn from the spatula blade and fall into the test tube.

After enough particles transfer, the salt is added to the test tube contents and processed by the chemistry engine.

The spatula always maintains a minimum height above the workbench to prevent sinking into the surface.

---

# 6. Dropper / Pipette Locking Logic

Droppers transfer liquid chemicals from reagent bottles into test tubes.

### Filling Logic (Reagent Bottles)
To withdraw liquid, the dropper uses a magnetic snap system for reagent bottles:
1. **Snap Threshold**: When the pipette is dragged near a bottle mouth, it magnetically snaps to the opening.
2. **Bottle Insertion**: The pipette tip enters the bottle neck and locks into position.
3. **Lock State**: While locked, horizontal movement is restricted, and the pipette aligns with the bottle axis.
4. **Filling**: Each right-click fills exactly **20%** of the pipette capacity.
5. **Visuals**: The liquid level and chemical color become visible inside the pipette glass.
6. **Unlock**: The pipette unlocks and returns to free-drag mode when the user drags it away from the bottle mouth.

### Pipette / Dropper Locking Logic for Test Tubes
To ensure precise dispensing, the dropper uses a magnetic locking mechanism when interacting with test tubes:

1. **Proximity Detection**: While dragging, if the distance between the pipette tip and the tube mouth is **less than 0.08 meters**, the magnetic lock activates.
2. **Mouth Alignment**: Upon activation, the pipette automatically centers itself over the tube mouth using a smooth interpolation (lerp factor 0.2).
3. **Height Positioning**: The pipette tip stops slightly inside the mouth at `tube.y + tubeHeight + 0.02`. It is prevented from going deeper or hitting the workbench.
4. **Lock State**: Once aligned, the pipette enters a **Locked State**. 
   - Horizontal movement is restricted.
   - Only vertical movement for small adjustments is allowed.
   - The pipette stops wobbling or tilting.
5. **Unlock Condition**: The pipette unlocks if the user drags strongly away from the tube (distance > 0.12 meters).
6. **One Click One Drop Rule**:
   - **Exclusivity**: A single user interaction must trigger exactly one drop event and one drop of chemical transfer.
   - **No Looping**: Automatic repeated drops or animation loops are strictly prohibited.
   - **Click Dependency**: Each subsequent drop requires a fresh user click.
   - **One-Shot Animation**: The drop animation must start, play, and finish completely before another drop can occur.
7. **Timing Separation**:
   - **Independent Timers**: Interaction timing (cooldown) must be independent of animation timing (`dropStartTime`).
   - **State Reset**: Once the animation finishes, the animation state must be reset to prevent automatic repetition.
8. **No Pre-Drop Animations**:
   - **Instant Appearance**: The drop must appear immediately at the pipette tip upon clicking.
   - **World-Space Fall**: The drop falls in world coordinates, independent of the pipette's subsequent movement or alignment.
   - **Surface Collision**: The drop must stop and disappear at the test tube's liquid surface, never falling through to the workbench.
   - **No Internal Flow**: Animations showing liquid traveling inside the pipette or multiple particles spawning before the drop are prohibited.
9. **Visual Feedback**:
   - **HUD Hint**: "LOCKED & ALIGNED - Right-Click to dispense drop" appears when engaged.
   - **Simplicity**: Only the falling drop particle and a single bulb squeeze animation trigger per click.

---

# 7. Test Tube Logic

Test tubes are the primary containers used for chemical reactions.

Each test tube tracks the following properties:

* Liquid volume
* Ion contents
* Reaction state
* Solution color
* Precipitate presence
* Heating state

The maximum liquid fill level is limited to prevent overflow.

When chemicals or salts are added, the chemistry engine recalculates the reaction outcome.

Visual indicators represent reactions inside the tube.

These indicators include:

* Color change in the liquid
* Bubble particles for gas formation
* Curdy particles for precipitate formation
* Fume particles for heated reactions

Test tubes can be cleaned by placing them near the sink or by using the reset option.

Cleaning removes all contents and resets the tube to an empty state.

---

# 8. Test Tube Stand Logic

The test tube stand holds multiple test tubes vertically.

The stand contains evenly spaced cylindrical holes.

When a test tube is dragged near a hole, it snaps into the center of the slot.

Once placed, the test tube remains vertically aligned.

The stand prevents the tube from falling or tilting.

Removing the tube requires dragging it upward out of the hole.

Test tubes placed in the stand remain stable during other laboratory operations.

---

# 9. Test Tube Holder Logic

The test tube holder is a handheld metal clamp used to grip a single test tube.

When the holder is moved near a test tube, it magnetically attaches to the tube.

Once attached, the holder locks the tube in place.

Moving the holder moves the test tube together with it.

To release the tube, the holder must be double clicked.

After release, the test tube becomes an independent object again.

The holder maintains a strong grip to prevent the tube from slipping during movement.

---

# 10. Retort Stand Logic

The retort stand consists of a vertical rod mounted on a heavy base.

The stand contains adjustable clamps used to hold apparatus such as test tubes.

A test tube placed inside a clamp becomes locked to the clamp position.

Moving the clamp changes the vertical position of the tube.

Moving the entire stand moves both the clamp and the tube together.

This allows experiments requiring stable positioning above heat sources.

---

# 11. Reagent Bottle Logic

Reagent bottles store liquid chemicals used during experiments.

Each bottle contains a specific chemical solution.

The bottle mouth acts as the filling point for droppers.

When a dropper tip enters the bottle mouth, it can draw liquid from the bottle.

Bottles snap into designated shelf slots to keep them organized.

Bottles cannot be tilted or poured directly.

All liquid transfers must occur using droppers.

---

# 12. Bunsen Burner Logic

The Bunsen burner provides a heating source for chemical reactions.

The burner contains a flame region above the burner nozzle.

A defined heating zone exists above the flame.

When a test tube enters this zone, the tube enters a heating state.

Heating may accelerate reactions or produce gases depending on the chemical mixture.

Visual effects during heating include:

* Rising fumes
* Increased bubbling
* Reaction color intensification

When the test tube leaves the heating zone, the heating state automatically stops.

---

# 13. Collision and Surface Safety Rules

All apparatus follow physical constraints to prevent unrealistic movement.

Objects cannot pass through the workbench surface.

Each apparatus maintains a minimum height above the surface to prevent clipping.

Dragging always occurs along valid surfaces.

When an apparatus is released, it stabilizes at the nearest valid position.
